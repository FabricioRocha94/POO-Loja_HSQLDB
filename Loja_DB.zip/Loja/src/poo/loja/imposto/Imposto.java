package poo.loja.imposto;

import poo.loja.modelo.Venda;

public interface Imposto {
	
	public double getValor(Venda venda);

}
